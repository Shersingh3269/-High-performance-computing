#include <iostream>
#include <cstdlib>
#include <vector>
#include <limits>
#include <cmath>
#include <omp.h>

using namespace std;

double *a, *b, *c_par;

void allocate(size_t dim);
void initialize(size_t dim);
void matmult_parallel(size_t dim);
void deallocate();
void print(double *a, size_t dim);
size_t compare(double *a, double *b, size_t dim);

int main()
{
    vector<size_t> dimensions;
    dimensions.push_back(10);
    dimensions.push_back(100);
    dimensions.push_back(1000);
    dimensions.push_back(4000);


    for (size_t i=0; i < dimensions.size(); i++)
    {
        size_t dim = dimensions[i];
        cout << endl
             << "Running " << dim << "x" << dim 
             << " Matrix Multiplication" << endl;

        allocate(dim);
        initialize(dim);
        matmult_parallel(dim);
        // cout << "Result of Parallel Mat Mult:" << endl;
        // print(c_ser, dim);
        deallocate();        
    }

    return 0;
}

void allocate(size_t dim)
{
    a = new double[dim*dim];
    b = new double[dim*dim];
    c_par = new double[dim*dim];
}

void initialize(size_t dim)
{
    // Initialize matrices
    for(size_t i = 0; i < dim; ++i)
    {
        for(size_t j = 0; j < dim; ++j)
        {
            a[i*dim+j] = (rand() % 100) + 1;
            b[i*dim+j] = (rand() % 100) + 1;
        }
    }
}

void deallocate()
{
    delete [] a;
    delete [] b;
    delete [] c_par;
}

void print(double *m, size_t dim)
{
    for (size_t i = 0; i < dim; ++i)
    {
        for(size_t j = 0; j < dim; ++j)
        {
            cout<<m[i*dim+j]<<"\t";
        }
        cout<<endl;
    }
}

size_t compare(double *a, double *b, size_t dim)
{
    size_t errors=0;
    for (size_t i = 0; i < dim; ++i)
    {
        for(size_t j = 0; j < dim; ++j)
        {

            bool eq = std::fabs(a[i*dim+j] - b[i*dim+j]) <= std::numeric_limits<double>::epsilon() ;
            errors += (eq == 0);
        }
    }
    return errors;
}

void matmult_parallel(size_t dim)
{
    // Multiplying matrix a and b and storing in array c_par.
    double tstart = omp_get_wtime(); // note the start time
    #pragma omp parallel for schedule(static)
    for(size_t i = 0; i < dim; ++i)
    {
        for(size_t j = 0; j < dim; ++j)
        {
            double temp = 0.0;
            for(size_t k = 0; k < dim; ++k)
            {
                temp += a[i*dim+k] * b[k*dim+j];
            }
            c_par[i*dim+j] = temp;
        }
    }
    double tend = omp_get_wtime(); // note the end time
    double exec_time = tend - tstart;

    // print the time of execution
    cout<< dim << " X " << dim 
        <<" parallel matmult time (sec): " << exec_time << endl;
}
