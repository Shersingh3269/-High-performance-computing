#include <stdio.h>
#include <time.h>
#include <mpi.h>

#define PI25DT 3.141592653589793238462643

#define INTERVALS 1000000000

int main(int argc, char **argv)
{
    long int i, intervals = INTERVALS;
    double x, dx, f, sum, pi, total_sum;

    // Initialization of MPI
    MPI_Init(&argc, &argv);

    // Get total number of ranks and the rank on each process
    int size, rank;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (rank == 0) {
        printf("\nmy rank: %d\n", rank);
        printf("world size: %d\n", size);
        printf("Number of intervals: %ld\n", intervals);
    }
    MPI_Barrier(MPI_COMM_WORLD);

    double tstart = MPI_Wtime();
    sum = 0.0;
    dx = 1.0 / (double) intervals;
    for (i = rank; i <= intervals; i+=size) {
        x = dx * ((double) (i - 0.5));
        f = 4.0 / (1.0 + x*x);
        sum = sum + f;
    }
    
    // sum up all parts
    MPI_Reduce(&sum, &total_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    
    // synchronize all the threads
    MPI_Barrier(MPI_COMM_WORLD);
    double tend = MPI_Wtime();

    if (rank == 0) {
        pi = dx*total_sum;
        printf("Computed PI %.24f\n", pi);
        printf("The true PI %.24f\n\n", PI25DT);
        printf("Elapsed time (sec) = %.2lf\n", tend - tstart);
    }

    MPI_Finalize();

    return 0;
}
